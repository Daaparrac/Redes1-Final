app.config( function($routeProvider){

	$routeProvider 
		.when('/',{
			templateUrl: 'views/login.html',
			controller: 'loginCtrl'
		})
		.when('/recuperarClave',{
			templateUrl: 'views/recuperarClave.html',
			controller: 'recuperarClaveCtrl'
		})
		.when('/misCitas',{
			templateUrl: 'views/misCitas.html',
			controller: 'misCitasCtrl'
		})
		.when('/citas',{
			templateUrl: 'views/citas.html',
			controller: 'citasCtrl'
		})
		.when('/profesionales',{
			templateUrl: 'views/profesionales.html',
			controller: 'profesionalesCtrl'
		})
		.when('/profesional/:codigo',{
			templateUrl: 'views/profesional.html',
			controller: 'profesionalCtrl'
		})
		.when('/centrosMedicos',{
			templateUrl: 'views/centrosMedicos.html',
			controller: 'centrosMedicosCtrl'
		})
		.when('/centroMedico/:codigo',{
			templateUrl: 'views/centroMedico.html',
			controller: 'centroMedicoCtrl'
		})
		.when('/citas/asignar/general',{
			templateUrl: 'views/asignarG.html',
			controller: 'asignarGCtrl'
		})
		.when('/citas/asignar/especialista',{
			templateUrl: 'views/asignarE.html',
			controller: 'asignarECtrl'
		})
		.when('/citas/asignar/:idcita',{
			templateUrl: 'views/asignarC.html',
			controller: 'asignarCCtrl'
		})
		.when('/citas/eliminar/:idcita',{
			templateUrl: 'views/asignarC.html',
			controller: 'asignarCCtrl'
		})
		.when('/pacientes',{
			templateUrl: 'views/pacientes.html',
			controller: 'pacientesCtrl'
		})
		.when('/paciente/:codigo',{
			templateUrl: 'views/paciente.html',
			controller: 'pacienteCtrl'
		})
		.when('/contactenos',{
			templateUrl: 'views/contactenos.html',
			controller: 'contactenosCtrl'
		})
		.otherwise({
			redirectTo: '/'
		});


});