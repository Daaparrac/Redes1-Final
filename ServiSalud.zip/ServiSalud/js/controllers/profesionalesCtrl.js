app.controller('profesionalesCtrl', ['$scope','$http', function($scope,$http){
	
	$scope.setActive("mProfesionales");

	$scope.profesionales = {};
	$scope.posicion = 5;

	$http.get('php/servicios/profesionales.listado.php')
		.then(function(response){

		var data = response.data;
		$scope.profesionales = data;
	});

	$scope.siguientes = function(){

		if($scope.profesionales.length > $scope.posicion){
			$scope.posicion += 5;
		};
	}

	$scope.anteriores = function(){

		if($scope.profesionales.length > 5 && $scope.posicion != 5){
			$scope.posicion -= 5;
		};
	}

}]);