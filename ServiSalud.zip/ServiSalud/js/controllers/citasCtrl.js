app.controller('citasCtrl', ['$scope', '$http', function ($scope, $http) {

	$scope.setActive("mCitas");

	$scope.citas = {};
	$scope.posicion = 5;

	$scope.cargando = true;

	$http.get('php/servicios/citas.listado.php')
		.then(function (response) {
			$scope.cargando = false;
			var data = response.data;
			$scope.citas = data;
		});

	$scope.navigate = function (a) {
		window.location = "#/citas/asignar/" + a;
		return;
	}

	$scope.siguientes = function () {

		if ($scope.citas.length > $scope.posicion) {
			$scope.posicion += 5;
		};
	}

	$scope.anteriores = function () {

		if ($scope.citas.length > 5 && $scope.posicion != 5) {
			$scope.posicion -= 5;
		};
	}


}]);