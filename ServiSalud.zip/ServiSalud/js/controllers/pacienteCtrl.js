app.controller('pacienteCtrl', ['$scope','$routeParams','$http', function($scope,$routeParams,$http){
	
	$scope.setActive("mPaciente");

	var codigo = $routeParams.codigo;

	$scope.actualizado = false;
	$scope.paciente = {};

	$scope.creando = false;
	$scope.cargando = false; 

	if(codigo == "nuevo" ){
		$scope.creando = true;

	}else{
		$scope.cargando = true; 
		$http.get('php/servicios/pacientes.getPaciente.php?c=' + codigo )
		.then(function(response){
		
		if( response.data.err !== undefined ){
			window.location = "#/pacientes";  /*revisar*/
			
			return;
		}

		var data = response.data;
		$scope.cargando = false; 
		$scope.paciente = data;

		});

	}




	$scope.guardarPaciente = function(){

		if ($scope.creando) {
		$scope.cargando = true; 
		$http.post('php/servicios/pacientes.crear.php', $scope.paciente).then(function(response){
			
			if(response.data.err === false){
				$scope.cargando = false; 
				$scope.actualizado = true;
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}else{
		$scope.cargando = true; 
		$http.post('php/servicios/pacientes.guardar.php', $scope.paciente).then(function(response){
			if(response.data.err === false){
				$scope.actualizado = true;
				$scope.cargando = false; 
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}

	}

}]);