app.controller('centroMedicoCtrl', ['$scope','$routeParams','$http', function($scope,$routeParams,$http){
	
	$scope.setActive("mCentrosmedicos");

	var codigo = $routeParams.codigo;

	$scope.actualizado = false;
	$scope.centroMedico = {};

	$scope.creando = false; 

	if(codigo == "nuevo" ){
		$scope.creando = true;

	}else{
		$http.get('php/servicios/centrosMedicos.getCentro.php?c=' + codigo )
		.then(function(response){

		if( response.data.err !== undefined ){
			window.location = "#/pacientes";  /*revisar*/
			return;
		}

		var data = response.data;
		$scope.centroMedico = data;

		});

	}




	$scope.guardarPaciente = function(){

		if ($scope.creando) {

		$http.post('php/servicios/pacientes.crear.php', $scope.centroMedico).then(function(response){
			if(response.data.err === false){
				$scope.actualizado = true;
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}else{

		$http.post('php/servicios/pacientes.guardar.php', $scope.centroMedico).then(function(response){
			if(response.data.err === false){
				$scope.actualizado = true;
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}

	}

}]);