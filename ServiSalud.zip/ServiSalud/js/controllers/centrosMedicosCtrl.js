app.controller('centrosMedicosCtrl', ['$scope','$http', function($scope,$http){
	
	$scope.setActive("mCentrosmedicos");

	$scope.centrosMedicos = {};
	$scope.posicion = 5;

	$http.get('php/servicios/centrosMedicos.listado.php')
		.then(function(response){

		var data = response.data;
		$scope.centrosMedicos = data;
	});

	$scope.siguientes = function(){

		if($scope.centrosMedicos.length > $scope.posicion){
			$scope.posicion += 5;
		};
	}

	$scope.anteriores = function(){

		if($scope.centrosMedicos.length > 5 && $scope.posicion != 5){
			$scope.posicion -= 5;
		};
	}

}]);