app.controller('recuperarClaveCtrl', ['$scope','$http','UserService', function($scope,$http,UserService){
	
	$scope.setActive("mLogin");

	$scope.login1 = {};
	$scope.idUsuario = {};

	$scope.recuperar = function(){

		$http.post('php/servicios/usuarios.guardar.php',  $scope.login1)
		.then(function(response){

		var data = response.data;
		console.log(data);
		
		window.location = "#/";  /*revisar*/
		return;
		});

	}

}]);