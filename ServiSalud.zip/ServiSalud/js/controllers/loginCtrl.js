app.controller('loginCtrl', ['$scope', '$http', 'UserService', function ($scope, $http, UserService) {

	$scope.setActive("mLogin");

	$scope.login1 = {};
	$scope.idUsuario = {};

	$scope.cargando = false;
	$scope.actualizado = false;
	$scope.ingresando = false;

	$scope.login = function () {

		$scope.cargando = true;
		$http.get('php/servicios/usuarios.getUsuario.php?c=' + $scope.login1.usuario + '&d=' + $scope.login1.password)
			.then(function (response) {

				var data = response.data;
				$scope.cargando = false;
				if(data.usuario == $scope.login1.usuario && data.password == $scope.login1.password){

					$scope.idUsuario = data.idusuarios;
					UserService.saveId($scope.idUsuario);
					
					$scope.ingresando = true;
					setTimeout(function() {
						 $scope.ingresando = false;
						 $scope.$apply();
					}, 3500)

					window.location = "#/citas"; /*revisar*/
					$scope.ingresando = true;
					return;;
				}
				else{
				
						$scope.actualizado = true;
						setTimeout(function() {
						 	$scope.actualizado = false;
						 	$scope.$apply();
						}, 3500)
					
				}

			})
			.catch(function (response) {
				$scope.cargando = false;
				console.error('Error', response.status, response.data);
			})
	}

}]);