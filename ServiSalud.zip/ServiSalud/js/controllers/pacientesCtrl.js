app.controller('pacientesCtrl', ['$scope','$http', function($scope,$http){
	
	$scope.setActive("mPacientes");

	$scope.pacientes = {};
	$scope.posicion = 5;
	$scope.cargando = true;
	$http.get('php/servicios/pacientes.listado.php')
		.then(function(response){

		var data = response.data;
		$scope.cargando = false;
		$scope.pacientes = data;
	});

	$scope.siguientes = function(){

		if($scope.pacientes.length > $scope.posicion){
			$scope.posicion += 5;
		};
	}

	$scope.anteriores = function(){

		if($scope.pacientes.length > 5 && $scope.posicion != 5){
			$scope.posicion -= 5;
		};
	}

}]);