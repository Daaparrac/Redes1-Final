app.controller('asignarCCtrl', ['$scope', '$routeParams', '$http', function ($scope, $routeParams, $http) {

	$scope.setActive("mCitas");

	var idcita = $routeParams.idcita;

	$scope.idUsuario = sessionStorage.getItem('idUser');
	$scope.cargando = true;
	$scope.citas = {};

	$http.get('php/servicios/citas.getCitas.php?c=' + idcita)
		.then(function (response) {
			$scope.cargando = true;
			if (response.data.err !== undefined) {
				window.location = "#/citas"; /*revisar*/
				$scope.cargando = false;
				return;
			}

			$scope.cargando = false;
			var data = response.data;
			$scope.citas = data;

		});

	




	$scope.guardarCita = function () {

		$scope.citas.id_paciente = $scope.idUsuario;
		$scope.cargando = true;
		$http.post('php/servicios/citas.guardar.php', $scope.citas).then(function (response) {
			
			if (response.data.err === false) {
				$scope.cargando = false;
				setTimeout(function () {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

			window.location = "#/misCitas";  /*revisar*/
			$scope.cargando = false;
			return;
		});

	}

	$scope.eliminarCita = function () {

		$scope.cargando = true;
		$http.post('php/servicios/citas.eliminar.php?c='+ idcita).then(function (response) {

			if (response.data.err === false) {
				$scope.cargando = false;
				$scope.actualizado = true;
				setTimeout(function () {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

			window.location = "#/misCitas";  /*revisar*/
			$scope.cargando = false;
			return;
		});

	}

}]);