app.controller('menuCtrl', ['$scope','$http', function($scope,$http){

    $scope.salir = function(){
        sessionStorage.removeItem('idUser');
        window.location = "#/";  /*revisar*/
		return;
    }
}]);