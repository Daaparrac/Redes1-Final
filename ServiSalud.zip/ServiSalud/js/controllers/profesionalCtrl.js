app.controller('profesionalCtrl', ['$scope','$routeParams','$http', function($scope,$routeParams,$http){
	
	$scope.setActive("mProfesionales");

	var codigo = $routeParams.codigo;

	$scope.actualizado = false;
	$scope.profesional = {};

	$scope.creando = false; 

	if(codigo == "nuevo" ){
		$scope.creando = true;

	}else{
		$http.get('php/servicios/profesionales.getProfesional.php?c=' + codigo )
		.then(function(response){

		if( response.data.err !== undefined ){
			window.location = "#/profesionales";  /*revisar*/
			return;
		}

		var data = response.data;
		$scope.profesional = data;

		});

	}




	$scope.guardarPaciente = function(){

		if ($scope.creando) {

		$http.post('php/servicios/profesional.crear.php', $scope.profesional).then(function(response){
			if(response.data.err === false){
				$scope.actualizado = true;
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}else{

		$http.post('php/servicios/profesional.guardar.php', $scope.profesional).then(function(response){
			if(response.data.err === false){
				$scope.actualizado = true;
				setTimeout(function() {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

		});

		}

	}

}]);