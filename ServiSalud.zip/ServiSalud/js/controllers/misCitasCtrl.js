app.controller('misCitasCtrl', ['$scope', '$http', 'UserService', function ($scope, $http, UserService) {

	$scope.setActive("mMisCitas");
	$scope.idUsuario = sessionStorage.getItem('idUser');
	$scope.citas = {};
	$scope.posicion = 5;
	$scope.cargando = true;

	$http.get('php/servicios/citasM.listado.php?c=' + $scope.idUsuario)
		.then(function (response) {

			if (response.data.err === false) {
				$scope.cargando = false;
				setTimeout(function () {
					$scope.actualizado = false;
					$scope.$apply();
				}, 3500)
			};

			var data = response.data;
			$scope.cargando = false;
			$scope.citas = data;
		});

	$scope.navigate = function (a) {
		window.location = "#/citas/eliminar/" + a;
		return;
	}

	$scope.siguientes = function () {

		if ($scope.citas.length > $scope.posicion) {
			$scope.posicion += 5;
		};
	}

	$scope.anteriores = function () {

		if ($scope.citas.length > 5 && $scope.posicion != 5) {
			$scope.posicion -= 5;
		};
	}


}]);