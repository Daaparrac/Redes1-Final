angular.module('userService', [])
    .factory('UserService', []);