var app = angular.module('serviSaludApp',['ngRoute','ui.mask']);

app.factory('UserService', function(){

	var idUser = {};
	
	idUser.saveId = function(a){

		sessionStorage.removeItem('idUser');
		idUser = a;
		sessionStorage.setItem('idUser', idUser);
		console.log(sessionStorage.getItem('idUser'));
	}
	return idUser
});

app.controller('mainCtrl', ['$scope','$http', function($scope,$http){
  
	$scope.menuSuperior = 'views/menu.html';
	$scope.telefonoMask = "999-9999";


	$scope.setActive = function(Opcion){

		$scope.mLogin  = "";
		$scope.mCitas = "";
		$scope.mPacientes    = "";
		$scope.mContactenos    = "";
		$scope.mMisCitas = "";
		$scope.mCentrosmedicos = "";
		$scope.mProfesionales = "";


		$scope[Opcion] = "active";

	}

}]);

// filtro personalizado de telefono 
app.filter('telefono',function(){

	return function(numero){
		return numero.substring(0,4) + "-" + numero.substring(4);
	}
});