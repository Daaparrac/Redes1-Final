<?php
error_reporting(0);

// Incluir la clase de base de datos
include_once("../classes/class.Database.php");

// Retorna un json
header('Content-Type: application/json');

$sql = "SELECT especialista.idespecialista, especialista.nombre, especialista.especialidad, centro_medico.centro_medico FROM especialista 	LEFT OUTER JOIN centro_medico ON especialista.idcentro_medico = centro_medico.idcentro_medico ORDER BY especialista.nombre ASC";

echo Database::get_json_rows($sql);

?>