<?php
// Incluir la clase de base de datos
include_once("../classes/class.Database.php");

// Verificar que venga el parametro
if (!isset($_GET['c'])) {
	echo json_encode( array('err' => true,'mensaje'=>"Falta el código") );
	die;
}

// Desinfectar el parametro
$idcita = htmlentities($_GET['c']);


$sql = "UPDATE citas SET
		id_paciente = NULL,
		estado  = '0'
		WHERE idcita = ".$idcita;



$Hecho = Database::ejecutar_idu($sql);
$Respuesta = "";

if ($Hecho == "1") {
	$Respuesta = json_encode( array('err' => false, 'mensaje'=>'Registro Actualizado.' ));
}else{
	$Respuesta = json_encode( array('err' => true, 'mensaje'=> $Hecho ));
}

echo $Respuesta;

?>