<?php
error_reporting(0);

// Incluir la clase de base de datos
include_once("../classes/class.Database.php");

// Retorna un json
header('Content-Type: application/json');

// Verificar que venga el parametro
if (!isset($_GET['c']) && !isset($_GET['d'])) {
	echo json_encode( array('err' => true,'mensaje'=>"Faltan los códigos") );
	die;
}

// Desinfectar el parametro
$user = htmlentities($_GET['c']);



    
$sql = "SELECT citas.idcita, citas.fecha, centro_medico.centro_medico, especialista.nombre, especialista.especialidad, tipo_cita.idtipo_cita, tipo_cita.tipo, citas.estado FROM citas LEFT OUTER JOIN centro_medico ON citas.idcentro_medico=centro_medico.idcentro_medico LEFT OUTER JOIN especialista ON citas.idespecialista=especialista.idespecialista LEFT OUTER JOIN tipo_cita ON citas.idtipo_cita=tipo_cita.idtipo_cita WHERE citas.id_paciente = ".$user;
echo Database::get_json_rows($sql);
    

    

?>