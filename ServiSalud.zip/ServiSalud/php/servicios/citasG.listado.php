<?php
error_reporting(0);

// Incluir la clase de base de datos
include_once("../classes/class.Database.php");

// Retorna un json
header('Content-Type: application/json');

$sql = "SELECT citas.idcita, citas.fecha, centro_medico.centro_medico, especialista.nombre, especialista.especialidad, tipo_cita.idtipo_cita, tipo_cita.tipo, citas.estado FROM citas LEFT OUTER JOIN centro_medico ON citas.idcentro_medico=centro_medico.idcentro_medico LEFT OUTER JOIN especialista ON citas.idespecialista=especialista.idespecialista LEFT OUTER JOIN tipo_cita ON citas.idtipo_cita=tipo_cita.idtipo_cita WHERE citas.estado = 0 AND citas.idtipo_cita = 1";

echo Database::get_json_rows($sql);

?>