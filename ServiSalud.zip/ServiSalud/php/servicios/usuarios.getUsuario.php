<?php
// Incluir la clase de base de datos
include_once("../classes/class.Database.php");

// Retorna un json
header('Content-Type: application/json;');

// Verificar que venga el parametro
if (!isset($_GET['c']) && !isset($_GET['d'])) {
	echo json_encode( array('err' => true,'mensaje'=>"Faltan los códigos") );
	die;
}

// Desinfectar el parametro
$user = htmlentities($_GET['c']);
$pass = htmlentities($_GET['d']);

// Verificar si existe
$sql = "SELECT count(*) as Existe FROM usuarios WHERE usuario = '$user' AND password = '$pass'";
$existe = Database::get_valor_query($sql,"Existe");


if ($existe == 1) {
	// Si existe, imprime el json
	$sql = "SELECT * FROM usuarios WHERE usuario = '$user' AND password = '$pass'";
	echo json_encode( Database::get_Row($sql) );	

}else{

	echo json_encode( array('err'=>true, 'mensaje'=>'Código no existe') );

}


?>